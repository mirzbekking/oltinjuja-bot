import os
from fastapi import FastAPI, Request
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
WEBHOOK_PATH = f"/webhook/{TOKEN}"
WEBHOOK_URL = os.getenv("WEBHOOK_URL") + WEBHOOK_PATH

bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())
app = FastAPI()

@app.on_event("startup")
async def on_startup():
    await bot.set_webhook(WEBHOOK_URL)
    print("Webhook ulandi:", WEBHOOK_URL)

@app.post(WEBHOOK_PATH)
async def telegram_webhook(req: Request):
    body = await req.body()
    update = types.Update.model_validate_json(body.decode("utf-8"))
    await dp.feed_update(bot, update)
    return {"ok": True}

@dp.message(commands=["start"])
async def start_handler(message: types.Message):
    await message.answer(
        "🍗 Xush kelibsiz 'Oltin Juja'!\n"
        "Bu yerda siz mazali qovurilgan tovuqni uyga buyurtma berishingiz mumkin!\n"
        "📞 Aloqa: +998 95 772 99 93"
    )
